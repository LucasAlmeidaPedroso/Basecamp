#include <unistd.h>

int	dig(int n)
{
	int	dig;

	dig = 0;
	while (n != 0)
	{
		n = n / 10;
		dig++;
	}
	return (dig);
}

int	pot(int base, int exp)
{
	int	pot;

	pot = 1;
	while (exp > 0)
	{
		pot = pot * base;
		exp--;
	}
	return (pot);
}

void	ft_putnbr(int nb)
{
	int	digit;
	int	result;

	if (nb == 0)
		write(1, "0", 1);
	if (nb == -2147483648)
		write(1, "-2147483648", 11);
	else
	{
		if (nb < 0)
		{
			write(1, "-", 1);
			nb = nb * -1;
		}
		result = 0;
		digit = dig (nb);
		while (digit > 0)
		{
			result = nb / pot(10, digit - 1);
			nb = nb(result * pot(10, digit - 1));
			result = result + 48;
			write(1, &result, 1);
			digit--;
		}
	}
}
