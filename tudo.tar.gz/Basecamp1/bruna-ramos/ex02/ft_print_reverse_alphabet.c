#include <unistd.h>

void	ft_print_reverse_alphabet(void)
{
	char	pink;

	pink = 'z';
	while (pink > 96)
	{
		write(1, &pink, 1);
		pink--;
	}	
}
