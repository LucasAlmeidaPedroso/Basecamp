#include <unistd.h>

void	print_number(char f, char s, char t)
{
	write(1, &f, 1);
	write(1, &s, 1);
	write(1, &t, 1);
	if (f + s + t != '7' + '8' + '9')
	{
		write(1, ", ", 2);
	}
}

void	ft_print_comb(void)
{
	char	f;
	char	s;
	char	t;

	f = '0';
	while (f <= '7')
	{
		s = f + 1;
		while (s <= '8')
		{
			t = s + 1;
			while (t <= '9')
			{
				print_number(f, s, t);
				t++;
			}
			s++;
		}
		f++;
	}
}
