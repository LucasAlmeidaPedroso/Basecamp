#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	pink;

	pink = 'a';
	while (pink < 123)
	{
		write(1, &pink, 1);
		pink++;
	}	
}
