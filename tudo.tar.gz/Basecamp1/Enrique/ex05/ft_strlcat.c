unsigned int	ft_strlcat (char *dest, char *src, unsigned int size);

unsigned int	find_null (char *p)
{
	int i;

	i = 0;
	while (p[i] != 0)
		i++;
	return (i);
}

unsigned int	length (char *p)
{
	int i;

	i = 0;
	while (p[i] != 0)
		i++;
	return (i);
}

unsigned int	ft_strlcat (char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	counter;

	i = find_null (dest);
	counter = 0;
	while (src[counter] != 0 && counter < (size - 1))
	{
		dest[i + counter] = src[counter];
	}
	dest[i + counter] = '\0';
	return (length(dest) + length (src));
}
