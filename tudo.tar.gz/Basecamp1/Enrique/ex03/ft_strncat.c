char	*ft_strncat (char *dest, char *src, unsigned int nb);

unsigned int	find_null (char *p)
{
	int	i;

	i = 0;
	while (p[i] != 0)
		i++;
	return (i);
}

char	*ft_strncat (char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	counter;

	i = find_null (dest);
	counter = 0;
	while (src[counter] != 0 && counter < nb)
	{
		dest[i + counter] = src[counter];
		counter++;
	}
	dest[i + counter] = '\0';
	return (dest);
}
