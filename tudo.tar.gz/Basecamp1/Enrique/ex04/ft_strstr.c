char	*ft_strstr (char *str, char *to_find);

int	length (char *c)
{
	int count;

	count = 0;
	while (c[count] != 0)
		count++;
	return (count);
}

int	search (char *c, char *target, int index, int flag)
{
	if (target[index] == 0 || flag == 0)
		return flag;
	if (c[index] == target[index])
	{
		return (search(c, target, index + 1, 1));
	}
	else
		return (search(c, target, index + 1, 0));
}

char	*ft_strstr (char *str, char *to_find)
{
	int		i;
	void	*limbo;

	limbo = 0;
	i = 0;
	while (str[i] != 0)
	{
		if (search(&str[i], to_find, 0, 1))
			return (&str[i]);
		i++;
	}
	return ((char *)limbo);
}
