char	*ft_strcat (char *dest, char *src);

int	find_null (char *p)
{
	int	i;

	i = 0;
	while (p[i] != 0)
		i++;
	return (i);
}

char	*ft_strcat (char *dest, char *src)
{
	int	i;
	int	counter;

	i = find_null (dest);
	counter = 0;
	while (src[counter] != 0)
	{
		dest[i + counter] = src[counter];
		counter++;
	}
	dest[i + counter] = src[counter];
	return (dest);
}
