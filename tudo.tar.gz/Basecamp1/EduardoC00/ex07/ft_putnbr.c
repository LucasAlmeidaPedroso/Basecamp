#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putchar_extra(int nb)
{
	if (nb == 0)
		write(1, "0", 1);
	if (nb == -2147483648)
	{
		write(1, "-", 1);
		write(1, "2147483648", 10);
	}
}

void	ft_putnbr(int nb)
{
	char	vector_number[10];
	int		count_numbers;

	count_numbers = 0;
	if (nb == 0 || nb == -2147483648)
		ft_putchar_extra(nb);
	else
	{
		if (nb < 0)
		{
			nb = nb * -1;
			ft_putchar('-');
		}
		while (nb > 0)
		{
			vector_number[count_numbers] = (nb % 10) + '0';
			nb = nb / 10;
			count_numbers += 1;
		}
		while (count_numbers > 0)
		{
			ft_putchar(vector_number[count_numbers - 1]);
			count_numbers -= 1;
		}
	}
}

/*
int	main(void)
{
	ft_putnbr(-2147483648);
	return (0);
}*/
