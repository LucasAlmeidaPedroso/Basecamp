#include <unistd.h>

void	print_result(char first_number, char second_number, char third_number)
{
	write (1, &first_number, 1);
	write (1, &second_number, 1);
	write (1, &third_number, 1);
	if (first_number == '7' && second_number == '8' && third_number == '9')
		return ;
	else
	{
		write (1, ",", 1);
		write (1, " ", 1);
	}
}

void	ft_print_comb(void)
{
	char	first_number;
	char	second_number;
	char	third_number;

	first_number = '0';
	second_number = '0';
	third_number = '0';
	while (first_number <= '9')
	{
		second_number = first_number + 1;
		while (second_number <= '9')
		{
			third_number = second_number + 1;
			while (third_number <= '9')
			{
				print_result (first_number, second_number, third_number);
				third_number += 1;
			}
			second_number += 1;
		}
		first_number += 1;
	}
}

/*
int	main(void)
{
	ft_print_comb();
	return (0);
}*/
