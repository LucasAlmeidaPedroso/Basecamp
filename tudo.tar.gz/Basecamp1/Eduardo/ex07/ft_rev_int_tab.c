/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lucde-al <lucde-al@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/11 20:06:29 by edfelipe          #+#    #+#             */
/*   Updated: 2021/06/12 18:24:00 by lucde-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	temp;
	int	i;
	int	j;

	i = 0;
	j = 1;
	while (i < size / 2)
	{
		temp = tab[i];
		tab[i] = tab[size - j];
		tab[size - j] = temp;
		i++;
		j++;
	}
}
