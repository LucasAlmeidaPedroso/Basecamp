#!/bin/sh
git log --format=%H -5
