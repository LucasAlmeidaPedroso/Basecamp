#include <unistd.h>

void	ft_print_comb2(void)
{
	int one;
	int two;

	one = 0;
	while (one < 99)
	{
		two = one +1;
		while(two <99)
		{
			
		}
	}
}