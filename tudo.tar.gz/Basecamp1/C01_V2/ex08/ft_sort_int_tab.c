void	ft_sort_int_tab(int *tab, int size)
{
	int	a;
	int	aux;

	a = 0;
	while (a < size - 1)
	{
		if (tab[a] > tab[a + 1])
		{
			aux = tab[a + 1];
			tab[a + 1] = tab[a];
			tab[a] = aux;
			a = -1;
		}
		a++;
	}
}
