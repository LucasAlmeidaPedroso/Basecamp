#include <stdio.h>
void	ft_rev_int_tab(int *tab, int size)
{
	int	a;
	int	b;

	a = 0;
	while (size > a)
	{
		b = tab[size - 1];
		tab[size - 1] = tab[a];
		tab[a] = b;
		size--;
		a++;
	}
}
