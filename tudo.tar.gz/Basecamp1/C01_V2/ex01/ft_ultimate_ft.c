void	ft_ultimate_ft(int *********nbr)
{
	int	n;

	n = 42;
	*********nbr = n;
}
