void	ft_ultimate_div_mod(int *a, int *b)
{
	int	vl1;
	int	vl2;

	vl1 = *a / *b;
	vl2 = *a % *b;
	*a = vl1;
	*b = vl2;
}
