void	ft_swap(int *a, int *b)
{
	int	vl1;

	vl1 = *b;
	*b = *a;
	*a = vl1;
}
