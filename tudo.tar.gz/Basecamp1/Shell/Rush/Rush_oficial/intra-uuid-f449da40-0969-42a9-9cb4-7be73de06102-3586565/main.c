#include <unistd.h>

void	rush(int x, int y);

int	main (void)
{
	rush (3, 4);
	return (0);
}
