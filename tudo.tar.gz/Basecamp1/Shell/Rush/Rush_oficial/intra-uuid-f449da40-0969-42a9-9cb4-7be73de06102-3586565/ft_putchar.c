#include <unistd.h>

void	ft_putchar (char c)
{
	write (1, &c, 1);
}

void	ft_body (int x, int y)
{
	int	count;

	count = 0;
	if (x > 2 && y == 2)
	{
		ft_putchar ('\n');
	}
	if (x > 2 && y > 2)
	{
		ft_putchar ('B');
		while (count < x - 2)
		{
			ft_putchar (' ');
			count++;
		}
		ft_putchar ('B');
	}
	if (x == 2 && y != 2)
	{
		write(1, "BB", 2);
	}
	if (x == 1)
	{
		write (1, "B", 1);
	}
}
