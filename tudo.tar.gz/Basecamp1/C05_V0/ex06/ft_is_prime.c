int	ft_is_prime(int nb)
{
	int	a;

	a = nb - 1;
	if (nb < 0 || a == 0)
		return (0);
	if (nb == 2)
		return (1);
	while (a != 1 )
	{
		if (nb % a == 0)
			return (0);
		a--;
	}
	return (1);
}
