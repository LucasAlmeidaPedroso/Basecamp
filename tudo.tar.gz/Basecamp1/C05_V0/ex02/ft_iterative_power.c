int	ft_iterative_power(int nb, int power)
{
	int	a;
	int	b;

	b = power;
	a = nb;
	if (power == 0)
		return (1);
	if (power < 0)
		return (0);
	while (b != 1)
	{
		a = a * nb;
		b--;
	}
	return (a);
}
