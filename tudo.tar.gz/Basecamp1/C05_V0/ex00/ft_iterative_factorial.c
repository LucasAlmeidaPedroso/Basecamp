int	ft_iterative_factorial(int nb)
{
	int	n;
	int	vl;

	n = 1;
	vl = 1;
	while (n <= nb)
	{
		vl = n * vl;
		n++;
	}
	if (nb > 0)
		return (vl);
	return (0);
}
