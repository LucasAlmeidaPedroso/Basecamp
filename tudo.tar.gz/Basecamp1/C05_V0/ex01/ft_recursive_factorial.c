int	ft_recursive_factorial(int nb)
{
	int	n;

	n = 0;
	if (nb < 0)
		return (0);
	if (nb == n || nb == 1)
		return (1);
	return (nb * ft_recursive_factorial(nb - 1));
}
