int	ft_atoi (char *str)
{
	int	result;
	int	a;
	int	b;

	a = 0;
	b = 1;
	result = 0;
	while (str[a] == ' ' || str[a] == '\f' || str[a] == '\n'
		|| str[a] == '\r' || str[a] == '\t' || str[a] == '\v')
		a++;
	while (str[a] == '+' || str[a] == '-')
	{
		if (str[a] == '-')
			b *= -1;
		a++;
	}
	while (str[a] >= '0' && str[a] <= '9')
	{
		result = result * 10;
		result = result + (str[a] - 48);
		a++;
	}
	result = result * b;
	return (result);
}
