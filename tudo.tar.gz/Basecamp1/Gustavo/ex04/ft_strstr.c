char	*ft_strstr(char *str, char *to_find)
{
	char	*bagstr;
	char	*bagfind;

	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{
		bagstr = str;
		bagfind = to_find;
		while (*bagstr == *bagfind && *bagfind != '\0' && *bagstr != '\0')
		{
			++bagstr;
			++bagfind;
		}
		if (*bagfind == '\0')
			return (str);
		++str;
	}
	return (0);
}
