char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char			*bag;
	unsigned int	count;

	count = 0;
	bag = dest;
	if (nb == 0)
		return (bag);
	while (*dest != '\0')
		dest++;
	while (*src != '\0' && count < nb)
	{
		*dest = *src;
		dest++;
		src++;
		count++;
	}
	*dest = '\0';
	return (bag);
}
