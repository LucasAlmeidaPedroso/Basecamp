unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	a;

	a = 0;
	while (a != size && src[a] != '\0')
	{
		dest[a] = src[a];
		a++;
	}
	dest[a - 1] = '\0';
	return (a);
}
