void	ft_putstr_non_printable(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] < 33 && str[a] > 126)
		{
			str[a - 1] = '\\';
		}
		a++;
	}
}
