char	ft_strlowcase(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] > 64 && str[a] < 91)
			str[a] = str[a] + 32;
		a++;
	}
	return (*str);
}

char	*ft_strcapitalize(char *str)
{
	int	a;

	ft_strlowcase(str);
	a = 0;
	while (str[a] != '\0')
	{	
		if (a == 0 && str[a] > 96 && str[a] < 123)
			str[a] = str[a] - 32;
		if (!((str[a] > 47 && str[a] < 58) || (str[a] > 64
					 && str[a] < 91) || (str[a] > 96 && str[a] < 123)))
		{
			if (str[a + 1] > 96 && str[a + 1] < 123 && str[a + 1] != '\0')
				str[a + 1] = str[a + 1] - 32;
		}
		a++;
	}
	return (str);
}
