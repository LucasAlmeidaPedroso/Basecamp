#include <stdio.h>
int        main(int argc, char **argv)
{
    int i;

    i = 0;
    ft_validation(argc, argv[1], i);
    return (0);
}


void    ft_putchar(char c);

int        ft_putstr(char *str);

int        ft_validation(int arg1, char *arg2, int i);

int        ft_error(void);

int        ft_validation2(char *arg2, int i);

char    **ft_puttab(char **tab);

void    ft_createheader(char *argv);

void    ft_putheader(char **header);

void    ft_prttab(char **tab);

void    ft_sorttab(char **tab);


int        ft_error(void)
{
    ft_putstr("Error\n");
    return (0);
}

int        ft_testnumbers2(char *arg2, int i, int tr)
{
    i = 0;
    tr = 0;
    while (arg2[i] != '\0')
    {
        if (arg2[i] == '3')
            tr++;
        if (tr > 8)
        {
            ft_error();
            return (0);
        }
        i++;
    }
    ft_createheader(arg2);
    return (0);
}

int        ft_testnumbers(char *arg2, int i)
{
    int        fr;
    int        on;
    int        tw;

    tw = 0;
    fr = 0;
    on = 0;
    i = 0;
    while (arg2[i] != '\0')
    {
        if (arg2[i] == '4')
            fr++;
        if (arg2[i] == '1')
            on++;
        if (arg2[i] == '2')
            tw++;
        if ((fr > 4) || (on > 4) || (tw > 8))
        {
            ft_error();
            return (0);
        }
        i++;
    }
    ft_testnumbers2(arg2, i, tw);
    return (0);
}

int        ft_validation2(char *arg2, int i)
{
    if (((i < 31)) || (((i % 2) == 0) && (arg2[i] == ' ')))
    {
        ft_error();
        return (0);
    }
    if (i >= 32)
    {
        ft_error();
        return (0);
    }
    ft_testnumbers(arg2, i);
    return (0);
}

int        ft_validation(int arg1, char *arg2, int i)
{
    if ((arg1 != 2) || (arg2 == '\0') || (arg2[30] == ' '))
    {
        ft_error();
        return (0);
    }
    while (arg2[i] != '\0')
    {
        if ((arg2[i] != ' ') && (arg2[i] != '1') && (arg2[i] != '2'))
        {
            if (((arg2[i] != '3') && (arg2[i] != '4')) || (i > 32))
            {
                ft_error();
                return (0);
            }
        }
        else if (((i % 2) == 1) && (arg2[i] != ' '))
        {
            ft_error();
            return (0);
        }
        i++;
    }
    ft_validation2(arg2, i);
    return (0);
}
[12:51]
FT_TABCREATE.C
#include <stdlib.h>


void    ft_sorttab2(char **tab)
{

    ft_prttab(tab);
}

void    ft_sorttab(char **tab)
{
    tab[2][1] = '2';
    tab[2][2] = '3';
    tab[2][3] = '4';
    tab[2][4] = '1';
    tab[3][1] = '3';
    tab[3][2] = '4';
    tab[3][3] = '1';
    tab[3][4] = '2';
    tab[4][1] = '4';
    tab[4][2] = '1';
    tab[4][3] = '2';
    tab[4][4] = '3';
    ft_sorttab2(tab);
}

void    ft_putheader(char **header)
{
    char    **square;
    int        i;

    i = -1;
    square = malloc(6 * sizeof(char *));
    while (i++ < 5)
        square[i] = malloc(6 * sizeof(char));
    ft_puttab(square);
    square[0][1] = *header[0];
    square[0][2] = *header[1];
    square[0][3] = *header[2];
    square[0][4] = *header[3];
    square[1][5] = *header[4];
    square[2][5] = *header[5];
    square[3][5] = *header[6];
    square[4][5] = *header[7];
    square[5][4] = *header[8];
    square[5][3] = *header[9];
    square[5][2] = *header[10];
    square[5][1] = *header[11];
    square[4][0] = *header[12];
    square[3][0] = *header[13];
    square[2][0] = *header[14];
    square[1][0] = *header[15];
    ft_sorttab(square);
}

void    ft_createheader(char *argv)
{
    int        i;
    int        j;
    char    **header;

    header = malloc(16 * sizeof(char *));
    i = 0;
    while (i < 16)
    {
        header[i] = malloc(1 * sizeof(char));
        i++;
    }
    i = 0;
    j = 0;
    while (i <= 30)
    {
        header[j] = &argv[i];
        j++;
        i += 2;
    }
    ft_putheader(header);
}
[12:52]
FT_PUTSTR.C
#include <unistd.h>
#include "header.h"

void    ft_putchar(char c)
{
    write(1, &c, 1);
}

int        ft_putstr(char *str)
{
    int        i;

    i = 0;
    while (str[i] != '\0')
    {
        ft_putchar(str[i]);
        i++;
    }
    return (0);
}

char    **ft_puttab(char **tab)
{
    int        i;
    int        j;

    j = 0;
    i = 0;
    while (i <= 5)
    {
        while (j <= 5)
        {
            if (j != 5)
                tab[i][j] = j + '0';
            else
                tab[i][j] = '0';
            j++;
        }
        j = 0;
        i++;
    }
    return (tab);
}

void    ft_prttab(char **tab)
{
    int        i;
    int        j;

    j = 1;
    i = 1;
    while (i <= 4)
    {
        while (j <= 4)
        {
            ft_putchar(*&(tab[i][j]));
            if (j < 4)
                ft_putchar(' ');
            j++;
        }
        ft_putchar('\n');
        j = 1;
        i++;
    }
}