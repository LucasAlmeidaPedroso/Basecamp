#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int i;
	char *a;

	i = 0;
	a = (char *) malloc (16 * 1);
	a = argv[1];
	while( i < 19 && a[i] != '\0')
	{
		printf("%c ", a[12]);
		i++;
	}
	return(0);
}