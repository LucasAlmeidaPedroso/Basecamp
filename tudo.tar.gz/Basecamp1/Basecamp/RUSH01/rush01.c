#include <stdio.h>

int main(void)
{
	int i = 10;
	int b = 20;
	int m[4][4] = {a[i],a2,};
	printf("teste valor: %d", m[0][0]);
	return(0);
}