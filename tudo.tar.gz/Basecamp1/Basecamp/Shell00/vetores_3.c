#include <unistd.h>
#include <stdio.h>

int main(void)
{
	float notas[4];
	int i;

	while( i < 4)
	{
	printf("digite o numero:" );
	scanf("%f", &notas[0] );

	printf("numero digitado: %2.f \n ", notas[0]);
	i++;
	}
}
