#include <stdio.h>
#include <unistd.h>

int main(void)
{
	int vet[10];
	int cont;
	int cont2;
	cont =0;
	cont2 =0;
	while(cont < 9)
	{
		printf("este é o valor de vet %d\n", cont );
		scanf ("%d", &vet[cont] );
		cont++;
	}
	
	while(cont2 < 9)
	{
		printf("este é o valor : %d\n", vet[cont2] );
		cont2++;
	}
}