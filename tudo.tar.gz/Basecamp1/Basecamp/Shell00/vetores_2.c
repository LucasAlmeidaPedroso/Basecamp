#include <unistd.h>
#include <stdio.h>

int main(void)
{
	int i;
	i=0;
	int vetores[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

		while(i < 20)
		{
		printf("teste vertor 2 valor = %d\n", vetores[i]);
		i++;
	}
	
}