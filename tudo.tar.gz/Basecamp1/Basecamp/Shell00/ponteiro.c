#include <unistd.h>
#include <stdio.h>

int main(void)
{
	int	a;
	int *ptr;
	int **pptr;

	
	a = 56;
	ptr =&a;
	*ptr = 10;
	pptr = &ptr;
	**pptr = 25;
	printf ("%d\n", a);
}