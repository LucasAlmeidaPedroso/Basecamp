#include <unistd.h>
#include <stdio.h>

int main(void)
{
	int v[25];
	int i;
	i = 0;

	while(i<20)
	{
		v[i]=i;
		printf("teste2 %d\n", v[i]);
		i++;
	}
		v[22]=5;
	printf("teste2 %d\n", v[22]);
}