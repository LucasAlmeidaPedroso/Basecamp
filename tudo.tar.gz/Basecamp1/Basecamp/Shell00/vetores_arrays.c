#include <stdio.h>

int main(void)
{
	int i, vetor[8];
	while (i < 10)
	{
		printf("teste [%d] = %d\n", i, vetor[i]);
		i++;
	}
}