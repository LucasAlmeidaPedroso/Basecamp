/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fabtakas <fabtakas@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/16 02:20:54 by fabtakas          #+#    #+#             */
/*   Updated: 2021/06/18 00:21:40 by fabtakas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_str_is_alpha(char *str)
{
	int	count;

	count = 0;
	while (str[count] != 0)
	{
		if ((str[count] < 'A' || str[count] > 'Z' )
			&& (str[count] < 'a' || str[count] > 'z'))
			return (0);
		count++;
	}
	return (1);
}
