/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fabtakas <fabtakas@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/16 19:56:48 by fabtakas          #+#    #+#             */
/*   Updated: 2021/06/17 22:26:37 by fabtakas         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	count;

	count = 0;
	while (str[count] != '\0')
	{
		if (str[count] >= 'A' && str[count] <= 'Z')
			str[count] = str[count] + 32;
		count++;
	}
	return (str);
}

char	*ft_strcapitalize(char *str)
{
	int	count;
	int	startword;

	ft_strlowcase(str);
	count = 0;
	startword = 1;
	while (str[count] != '\0')
	{
		if (str[count] >= 'a' && str[count] <= 'z')
		{
			if (startword == 1)
				str[count] = str[count] - 32;
			 startword = 0;
		}
		else if (str[count] >= '0' && str[count] <= '9')
			startword = 0;
		else
			startword = 1;
		count++;
	}
	return (str);
}
