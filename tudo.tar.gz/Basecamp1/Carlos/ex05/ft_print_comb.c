#include <unistd.h>

void	ft_putchar (char c)
{
	write(1, &c, 1);
}

void	ft_i (char a, char b, char c, char u)
{
	ft_putchar(a);
	ft_putchar(b);
	ft_putchar(c);
	if (u)
	{
		ft_putchar (',');
		ft_putchar (' ');
	}
}

void	ft_print_comb (void)
{
	char	a;
	char	b;
	char	c;
	char	u;

	a = 48;
	while (a <= 55)
	{
		b = a + 1;
		while (b <= 56)
		{
			c = b + 1;
			while (c <= 57)
			{
				u = !(a == 55);
				ft_i (a, b, c, u);
				c++;
			}
			b++;
		}
		a++;
	}
}
