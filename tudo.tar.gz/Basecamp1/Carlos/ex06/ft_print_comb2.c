#include <unistd.h>

void	ft_putchar (char c)
{
	write(1, &c, 1);
}

void	ft_i (int n1, int n2, char u)
{
	ft_putchar (n1 / 10 + '0');
	ft_putchar (n1 % 10 + '0');
	ft_putchar (' ');
	ft_putchar (n2 / 10 + '0');
	ft_putchar (n2 % 10 + '0');
	if (u)
	{
		ft_putchar (',');
		ft_putchar (' ');
	}
}

void	ft_print_comb2 (void)
{
	int		n1;
	int		n2;
	char	u;

	n1 = 0;
	while (n1 <= 99)
	{
		n2 = n1 + 1;
		while (n2 <= 99)
		{
			u = !(n1 == 98 && n2 == 99);
			ft_i (n1, n2, u);
			n2++;
		}
		n1++;
	}
}
