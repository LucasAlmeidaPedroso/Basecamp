#include	<unistd.h>

void	ft_print_reverse_alphabet(void)
{
	char	l;

	l = 'z';
	while (l >= 'a')
	{
		write (1, &l, 1);
		l-- ;
	}
}
