#include	<unistd.h>

void	ft_putchar(char j);
void	ft_checkputchar(char n1, char n2, char n3, char n4);
void	ft_navnb(char n1, char n2, char n3, char n4);

void	ft_print_comb2(void)
{
	char	n1;
	char	n2;
	char	n3;
	char	n4;

	n1 = '0';
	n2 = '0';
	n3 = '0';
	n4 = '0';
	ft_navnb(n1, n2, n3, n4);
}

void	ft_navnb(char n1, char n2, char n3, char n4)
{
	while (n1 <= '9')
	{
		while (n2 <= '9')
		{
			while (n3 <= '9')
			{
				while (n4 <= '9')
				{
					ft_checkputchar(n1, n2, n3, n4);
					n4++ ;
				}
				n4 = '0';
				n3++ ;
			}
			n3 = '0';
			n2++ ;
		}
		n2 = '0';
		n1++ ;
	}
}

void	ft_checkputchar(char n1, char n2, char n3, char n4)
{
	if ((n3 == n1 && n4 > n2) || (n3 > n1))
	{
		ft_putchar(n1);
		ft_putchar(n2);
		ft_putchar(32);
		ft_putchar(n3);
		ft_putchar(n4);
		if (n1 == '9' && n2 == '8' && n3 == '9' && n4 == '9')
		{
			return ;
		}
		else
		{
			ft_putchar(44);
			ft_putchar(32);
		}
	}
}

void	ft_putchar(char j)
{
	write (1, &j, 1);
}
