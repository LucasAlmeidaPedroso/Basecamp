#include	<unistd.h>

void	ft_print_combn(int n)
{
	write(1, &n, 1);
}
