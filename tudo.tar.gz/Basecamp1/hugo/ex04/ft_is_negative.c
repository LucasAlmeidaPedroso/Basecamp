#include	<unistd.h>

void	ft_putchar(char j);

void	ft_is_negative(int n)
{
	char	R;
	
	if (n < 0)
	{
		R = 'N';
		ft_putchar(R);
	}
	else
	{
		R = 'P';
		ft_putchar(R);
	}
}
	
void	ft_putchar(char j)
{
	write (1, &j, 1);
}
