#include	<unistd.h>

void	ft_putchar(char j);
int		ft_valida(char n1, char n2, char n3);

void	ft_print_comb(void)
{
	char	n1;
	char	n2;
	char	n3;
	int		r;

	n1 = '0';
	n2 = '0';
	n3 = '0';
	while (n1 <= '9')
	{
		while (n2 <= '9')
		{
			while (n3 <= '9')
			{
				r = ft_valida(n1, n2, n3);
				if (r == 1)
					break ;
				n3++ ;
			}
			n3 = '0';
			n2++ ;
		}
		n2 = '0';
		n1++ ;
	}
}

int	ft_valida(char n1, char n2, char n3)
{
	if (n3 > n2 && n2 > n1)
	{
		ft_putchar(n1);
		ft_putchar(n2);
		ft_putchar(n3);
		if (n1 == '7')
			return (1);
		ft_putchar(44);
		ft_putchar(32);
	}
	return (0);
}

void	ft_putchar(char j)
{
	write (1, &j, 1);
}
