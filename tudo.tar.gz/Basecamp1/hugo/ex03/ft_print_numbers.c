#include	<unistd.h>

void	ft_print_numbers(void)
{
	int	n;
	int a;

	n = 0;
	while (n < 10 )
	{
		write(1, &a, 1);
		a++
		n++ ;
	}
}
