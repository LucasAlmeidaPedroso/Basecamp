void	*ft_print_memory(void *addr, unsigned int size)
{
	unsigned int c;

	c = 0;
	
	while(c < size)
	{
		
		c++;
	}

}
int main(void)
{
	char addr[] = {"testando"};
	unsigned int size = 8;

	ft_print_memory(addr, size);
	return (0);
}