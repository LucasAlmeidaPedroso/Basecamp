#include<unistd.h>

char	*ft_strlowcase(char *str)
{
	int		c;
	int		intc;
	char	chac;

	c = 0;
	intc = 0;
	chac = '0';
	while (*str)
	{
		intc = (int)str[c];
		if (intc > 64 && intc < 91)
		{
			chac = intc + 32;
			str[c - 1] = chac;
		}
		str++;
	}
	return (str);
}
