unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
}
