#include <unistd.h>

void	ft_putchar(char d, char u)
{
	write(1, &d, 1);
	write(1, &u, 1);
}

void	ft_int_char(int num, int limt)
{
	char	u;
	char	d;

	if (num <= 9)
	{
		u = num + 48;
		ft_putchar('0', u);
	}
	else if (num <= limt)
	{
		u = (num % 10) + 48;
		d = (num / 10) + 48;
		ft_putchar(d, u);
	}
}

void	ft_printnumber(int col1, int col2)

{
	ft_int_char(col1, 98);
	write(1, " ", 1);
	ft_int_char(col2, 99);
	if ((col1 != 98) || (col2 != 99))
	{
		ft_putchar(',', ' ');
	}
}

void	ft_print_comb2 (int col01, int col02)
{
	col01 = 0;
	while (col01 <= 98)
	{
		col02 = col01 + 1;
		while (col02 <= 99)
		{
			ft_printnumber(col01, col02);
			col02++;
		}
		col01++;
	}
}
