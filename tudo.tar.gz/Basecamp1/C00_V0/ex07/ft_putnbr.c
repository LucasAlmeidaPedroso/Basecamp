#include <unistd.h>

void ft_putnbr( int nb)
{
	char	c; 
	int		num;

	while( nb != 0)
	{
		num = nb % 10;
		c = 48 + num;
		write(1, &c, 1);
		nb--;
	}
	int ft_pow(int base, int exp)
	{

	int resultado;
	
	resultado = 1;
	while(exp > 0)
	{
		resultado = resultado * base;
		exp = exp -1;
	}
}