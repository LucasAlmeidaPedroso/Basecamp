#include <unistd.h>
void	ft_count(int c, int d, int u)
{
	write(1, &c, 1);
	write(1, &d, 1);
	write(1, &u, 1);
	if (c == '7' && d == '8' && u == '9')
	{
	}
	else
		write(1, ", ", 2);
}

void	ft_print_comb(void)
{
	int	u;
	int	d;
	int	c;

	u = '2';
	d = '1';
	c = '0';
	while (c <= '7' )
	{
		while (d <= '8' )
		{
			while (u <= '9')
			{
				ft_count(c, d, u);
				u++;
			}
			u = d + 2;
			d++;
		}
		d = c + 1;
		c++;
	}
}
